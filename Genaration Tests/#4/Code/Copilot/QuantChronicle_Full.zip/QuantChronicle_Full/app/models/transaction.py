class Transaction: pass
