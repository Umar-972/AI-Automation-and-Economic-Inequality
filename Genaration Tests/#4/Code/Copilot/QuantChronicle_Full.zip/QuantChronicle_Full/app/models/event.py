class Event: pass
